﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaquinExpendedora_Ejercicio
{
    public partial class Adminitracion : Form
    {
        // Evento para notificar cuando se agrega un producto
        public event EventHandler ProductoAgregado;

        public Adminitracion()
        {
            InitializeComponent();
            ConfigurarInterfazModerna();
        }

        private void ConfigurarInterfazModerna()
        {
            // Configuración del formulario principal
            this.BackColor = Color.FromArgb(20, 20, 25);
            this.ForeColor = Color.White;
            this.Text = "Panel de Administracion";
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(900, 600);

            CrearPanelPrincipal();

            EstilizarBoton(button1, "📊 VER REPORTE COMPLETO", Color.FromArgb(33, 150, 243), Color.White);
            EstilizarBoton(button2, "❌ CIERRE DE CAJA", Color.FromArgb(244, 67, 54), Color.White);
            EstilizarBoton(button3, "➕ LLENAR", Color.FromArgb(244, 67, 54), Color.White);
            EstilizarBoton(Agregar, "➕ AGREGAR PRODUCTO", Color.FromArgb(76, 175, 80), Color.White);

            // Estilo para TextBox
            EstilizarTextBox(Tproducto);

            // Estilo para Labels
            EstilizarLabel(label1, "🏷️ CÓDIGO DEL PRODUCTO:");
            EstilizarLabel(lcantidad);

            // Configurar posiciones mejoradas
            RedistribuirControles();
        }

        private void CrearPanelPrincipal()
        {
         
            Panel panelFondo = new Panel()
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(35, 39, 46)
            };
            panelFondo.Paint += PanelFondo_Paint;
            this.Controls.Add(panelFondo);

            Panel panelContenido = new Panel()
            {
                Size = new Size(700, 400),
                BackColor = Color.FromArgb(45, 49, 56),
                Location = new Point(100, 80)
            };
            panelContenido.Paint += PanelContenido_Paint;
            panelFondo.Controls.Add(panelContenido);

          
            foreach (Control control in this.Controls.OfType<Control>().ToList())
            {
                if (control != panelFondo)
                {
                    this.Controls.Remove(control);
                    panelContenido.Controls.Add(control);
                }
            }

       
            Label titulo = new Label()
            {
                Text = "ADMINISTRACIÓN DE PRODUCTOS",
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                ForeColor = Color.White,
                Size = new Size(600, 40),
                Location = new Point(50, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };
            panelContenido.Controls.Add(titulo);

          
            Panel linea = new Panel()
            {
                Size = new Size(600, 2),
                Location = new Point(50, 65),
                BackColor = Color.FromArgb(76, 175, 80)
            };
            panelContenido.Controls.Add(linea);
        }

        private void PanelFondo_Paint(object sender, PaintEventArgs e)
        {
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                this.ClientRectangle,
                Color.FromArgb(20, 20, 25),
                Color.FromArgb(35, 39, 46),
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        private void PanelContenido_Paint(object sender, PaintEventArgs e)
        {
            Panel panel = sender as Panel;
            
            // Borde redondeado
            using (var pen = new Pen(Color.FromArgb(76, 175, 80), 2))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
            }

            // Sombra interna
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                panel.ClientRectangle,
                Color.FromArgb(45, 49, 56),
                Color.FromArgb(55, 59, 66),
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, panel.ClientRectangle);
            }
        }

        private void RedistribuirControles()
        {
            // Reposicionar controles para mejor diseño
            label1.Location = new Point(80, 120);
            Tproducto.Location = new Point(280, 115);
            Tproducto.Size = new Size(200, 30);

            lcantidad.Location = new Point(500, 120);
            lcantidad.Size = new Size(150, 30);

            Agregar.Location = new Point(200, 180);
            Agregar.Size = new Size(250, 50);

            button1.Location = new Point(200, 260);
            button1.Size = new Size(250, 50);

            button2.Location = new Point(200, 340);
            button2.Size = new Size(250, 50);

            button3.Location = new Point(500, 340);
            button3.Size = new Size(100, 50);

            // Agregar panel de instrucciones
            CrearPanelInstrucciones();
        }

        private void CrearPanelInstrucciones()
        {
            Panel panelInstrucciones = new Panel()
            {
                Size = new Size(600, 60),
                Location = new Point(50, 320),
                BackColor = Color.FromArgb(25, 25, 30)
            };

            Label instrucciones = new Label()
            {
                Text = "💡Instrucciones: Ingrese el código del producto y presione 'Agregar' para aumentar el stock",
                Font = new Font("Segoe UI", 10F, FontStyle.Regular),
                ForeColor = Color.FromArgb(200, 200, 200),
                Size = new Size(580, 40),
                Location = new Point(10, 10),
                TextAlign = ContentAlignment.MiddleLeft
            };

            panelInstrucciones.Controls.Add(instrucciones);
            
            // Buscar el panel de contenido y agregarlo ahí
            foreach (Control control in this.Controls)
            {
                if (control is Panel panel && panel.Controls.Count > 0)
                {
                    panel.Controls.Add(panelInstrucciones);
                    break;
                }
            }
        }

        private void EstilizarBoton(Button boton, string texto, Color colorFondo, Color colorTexto)
        {
            boton.Text = texto;
            boton.BackColor = colorFondo;
            boton.ForeColor = colorTexto;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 0;
            boton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            boton.Cursor = Cursors.Hand;
            
            // Efectos hover
            boton.MouseEnter += (s, e) => {
                boton.BackColor = Color.FromArgb(
                    Math.Min(255, colorFondo.R + 20), 
                    Math.Min(255, colorFondo.G + 20), 
                    Math.Min(255, colorFondo.B + 20));
            };
            boton.MouseLeave += (s, e) => boton.BackColor = colorFondo;
        }

        private void EstilizarTextBox(TextBox textBox)
        {
            textBox.BackColor = Color.FromArgb(60, 60, 65);
            textBox.ForeColor = Color.White;
            textBox.BorderStyle = BorderStyle.FixedSingle;
            textBox.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            textBox.TextAlign = HorizontalAlignment.Center;

            if (string.IsNullOrEmpty(textBox.Text))
            {
                textBox.Text = "Ej: A1";
                textBox.ForeColor = Color.Gray;
            }

            textBox.Enter += (s, e) => {
                if (textBox.Text == "Ej: A1")
                {
                    textBox.Text = "";
                    textBox.ForeColor = Color.White;
                }
            };

            textBox.Leave += (s, e) => {
                if (string.IsNullOrEmpty(textBox.Text))
                {
                    textBox.Text = "Ej: A1";
                    textBox.ForeColor = Color.Gray;
                }
            };
        }

        private void EstilizarLabel(Label label, string texto = null)
        {
            if (texto != null) label.Text = texto;
            label.ForeColor = Color.FromArgb(220, 220, 220);
            label.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Mostrar reporte con estilo mejorado
            string reporte = Operaciones.Reporte();
            MostrarReporteEstilizado(reporte);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Mostrar reporte con estilo mejorado
            string cierre = Operaciones.Cierre();
            MostrarReporteEstilizado(cierre);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Llamar a la función para llenar inventario inicial
            Operaciones.LlenarInicial();
            
            // Crear mensaje de confirmación
            string mensaje = "✅ INVENTARIO INICIALIZADO\n\n";
            mensaje += "Se han agregado 5 unidades de cada producto al inventario.\n\n";
            mensaje += "📦 PRODUCTOS CARGADOS:\n";
            mensaje += "• A1-A3: Snacks y aperitivos\n";
            mensaje += "• B1-B3: Bebidas básicas\n";
            mensaje += "• C1-C3: Bebidas premium\n";
            mensaje += "• D1-D3: Snacks diversos\n";
            mensaje += "• E1-E3: Productos especiales\n\n";
            mensaje += "Total: 75 productos agregados (15 tipos × 5 unidades)";
            

            MostrarReporteEstilizado(mensaje);
            ProductoAgregado?.Invoke(this, EventArgs.Empty);
        }

        private void MostrarReporteEstilizado(string reporte)
        {
            Form reporteForm = new Form()
            {
                Text = "📊 Reporte Detallado de Inventario",
                Size = new Size(700, 600),
                BackColor = Color.FromArgb(20, 20, 25),
                ForeColor = Color.White,
                StartPosition = FormStartPosition.CenterParent,
                Font = new Font("Segoe UI", 10F)
            };

            // Panel principal del reporte
            Panel panelReporte = new Panel()
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(35, 39, 46),
                Padding = new Padding(20)
            };

            // Título del reporte
            Label tituloReporte = new Label()
            {
                Text = "📊 REPORTE DE INVENTARIO DETALLADO",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.White,
                Dock = DockStyle.Top,
                Height = 50,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // RichTextBox para el contenido
            RichTextBox rtbReporte = new RichTextBox()
            {
                Text = reporte,
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(25, 25, 30),
                ForeColor = Color.FromArgb(200, 200, 200),
                Font = new Font("Consolas", 11F),
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                Margin = new Padding(0, 10, 0, 0)
            };

            // Botón de cerrar
            Button btnCerrar = new Button()
            {
                Text = "❌ CERRAR",
                Size = new Size(120, 40),
                BackColor = Color.FromArgb(244, 67, 54),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Dock = DockStyle.Bottom,
                Cursor = Cursors.Hand
            };
            btnCerrar.FlatAppearance.BorderSize = 0;
            btnCerrar.Click += (s, e) => reporteForm.Close();

            panelReporte.Controls.Add(rtbReporte);
            panelReporte.Controls.Add(tituloReporte);
            panelReporte.Controls.Add(btnCerrar);
            reporteForm.Controls.Add(panelReporte);

            reporteForm.ShowDialog();
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            string codigo = Tproducto.Text.Trim().ToUpper();

            if (string.IsNullOrWhiteSpace(codigo) || codigo == "EJ: A1")
            {
                MostrarMensaje("⚠️ Por favor ingrese un código de producto válido", "Advertencia", MessageBoxIcon.Warning);
                return;
            }

            if (!Operaciones.ProductoExiste(codigo))
            {
                MostrarMensaje($"❌ El producto {codigo} no existe", "Error", MessageBoxIcon.Error);
                lcantidad.Text = "❌ Producto no válido";
                lcantidad.ForeColor = Color.FromArgb(244, 67, 54);
                return;
            }
            
            string nombreProducto = Operaciones.dNombres[codigo];
            string resultado = Operaciones.buscarProducto(codigo);
            lcantidad.Text = $"✅ {resultado}";
            lcantidad.ForeColor = Color.FromArgb(76, 175, 80);
            
            // Limpiar el textbox después de agregar
            Tproducto.Text = "Ej: A1";
            Tproducto.ForeColor = Color.Gray;
            Tproducto.Focus();

            // Mostrar mensaje de éxito
            MostrarMensaje($"{nombreProducto} agregado exitosamente", "Éxito", MessageBoxIcon.Information);

            // Disparar el evento para notificar a Form1 que se agregó un producto
            ProductoAgregado?.Invoke(this, EventArgs.Empty);
        }

        private void MostrarMensaje(string mensaje, string titulo, MessageBoxIcon icono = MessageBoxIcon.Information)
        {
            MessageBox.Show(mensaje, titulo, MessageBoxButtons.OK, icono);
        }

        private void Adminitracion_Load(object sender, EventArgs e)
        {
            // Centrar el formulario y configuración inicial
            this.CenterToScreen();
            
            // Configurar estado inicial
            lcantidad.Text = "Listo para agregar productos";
            lcantidad.ForeColor = Color.FromArgb(33, 145, 143);
        }

        private void Tproducto_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
