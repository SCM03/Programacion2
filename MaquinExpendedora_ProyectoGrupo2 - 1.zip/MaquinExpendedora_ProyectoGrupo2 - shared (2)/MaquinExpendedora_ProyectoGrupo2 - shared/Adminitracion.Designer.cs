﻿namespace MaquinExpendedora_Ejercicio
{
    partial class Adminitracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Tproducto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Agregar = new System.Windows.Forms.Button();
            this.lcantidad = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(300, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(219, 75);
            this.button1.TabIndex = 0;
            this.button1.Text = "REPORTE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Tproducto
            // 
            this.Tproducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tproducto.Location = new System.Drawing.Point(212, 34);
            this.Tproducto.Multiline = true;
            this.Tproducto.Name = "Tproducto";
            this.Tproducto.Size = new System.Drawing.Size(63, 26);
            this.Tproducto.TabIndex = 1;
            this.Tproducto.TextChanged += new System.EventHandler(this.Tproducto_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ingrese el codigo";
            // 
            // Agregar
            // 
            this.Agregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agregar.Location = new System.Drawing.Point(287, 81);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(245, 68);
            this.Agregar.TabIndex = 3;
            this.Agregar.Text = "Agregar Producto";
            this.Agregar.UseVisualStyleBackColor = true;
            this.Agregar.Click += new System.EventHandler(this.Agregar_Click);
            // 
            // lcantidad
            // 
            this.lcantidad.AutoSize = true;
            this.lcantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcantidad.Location = new System.Drawing.Point(519, 124);
            this.lcantidad.Name = "lcantidad";
            this.lcantidad.Size = new System.Drawing.Size(0, 25);
            this.lcantidad.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(300, 274);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(219, 75);
            this.button2.TabIndex = 5;
            this.button2.Text = "CIERRE DE CAJA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(300, 363);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(219, 75);
            this.button3.TabIndex = 6;
            this.button3.Text = "LLENAR INCIAL";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Adminitracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lcantidad);
            this.Controls.Add(this.Agregar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Tproducto);
            this.Controls.Add(this.button1);
            this.Name = "Adminitracion";
            this.Text = "Adminitracion";
            this.Load += new System.EventHandler(this.Adminitracion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Tproducto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Agregar;
        private System.Windows.Forms.Label lcantidad;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}