﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaquinExpendedora_Ejercicio
{
    public partial class Form1 : Form
    {
        Operaciones op = new Operaciones();   // instancia de la clase operaciones

        public Form1()
        {
            InitializeComponent();
            AplicarTemaModerno();
        }

        // Método público para actualizar el inventario desde otros formularios
        public void ActualizarInventario()
        {
            ConfigurarLabelsConStock();
        }

        private void AplicarTemaModerno()
        {
            // Configuración del formulario principal
            this.BackColor = Color.FromArgb(20, 20, 25);
            this.Text = "Maquina Expendedora";
            this.WindowState = FormWindowState.Maximized;

            // Panel principal con degradado
            panel1.BackColor = Color.FromArgb(35, 39, 46);
            panel1.Paint += Panel1_Paint; // Para efectos de degradado

            // Configurar TableLayoutPanel
            tableLayoutPanel1.BackColor = Color.Transparent;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;

            // Estilizar área de control
            ConfigurarAreaControl();
            
            // efectos a botones de productos
            AplicarEfectosBotones();
            
            // Estilizar labels
            EstilizarLabels();
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {
            // efecto de degradado en el panel
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                panel1.ClientRectangle,
                Color.FromArgb(35, 39, 46),
                Color.FromArgb(45, 49, 56),
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, panel1.ClientRectangle);
            }
        }

        private void ConfigurarAreaControl()
        {
            // Estilizar área de resultado
            LResultado.BackColor = Color.FromArgb(25, 25, 30);
            LResultado.ForeColor = Color.FromArgb(100, 255, 100); // Verde neón
            LResultado.Font = new Font("Consolas", 14F, FontStyle.Bold);
            LResultado.BorderStyle = BorderStyle.None;
            LResultado.Text = "🔹 Seleccione su producto favorito";

            // Estilizar TextBox de código
            Tcodigo.BackColor = Color.FromArgb(45, 45, 50);
            Tcodigo.ForeColor = Color.White;
            Tcodigo.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            Tcodigo.BorderStyle = BorderStyle.FixedSingle;

            // Estilizar TextBox de monto
            tmonto.BackColor = Color.FromArgb(45, 45, 50);
            tmonto.ForeColor = Color.White;
            tmonto.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            tmonto.BorderStyle = BorderStyle.FixedSingle;

            // Labels de instrucción
            labelDigiteCodigo.ForeColor = Color.FromArgb(220, 220, 220);
            labelDigiteCodigo.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labelDigiteCodigo.Text = "CÓDIGO DEL PRODUCTO:";

            labelMonto.ForeColor = Color.FromArgb(220, 220, 220);
            labelMonto.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            labelMonto.Text = "💰 PAGA CON:";

            // Botones principales
            EstilizarBotonPrincipal(button1, "🛒 COMPRAR", Color.FromArgb(76, 175, 80));
            EstilizarBotonPrincipal(button2, "📊 REPORTE", Color.FromArgb(33, 150, 243));

            // CheckBoxes
            EstilizarCheckBoxes();
        }

        private void EstilizarBotonPrincipal(Button boton, string texto, Color color)
        {
            boton.Text = texto;
            boton.BackColor = color;
            boton.ForeColor = Color.White;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 0;
            boton.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            boton.Cursor = Cursors.Hand;

            // Efectos hover
            boton.MouseEnter += (s, e) => {
                boton.BackColor = Color.FromArgb(
                    Math.Min(255, color.R + 30),
                    Math.Min(255, color.G + 30),
                    Math.Min(255, color.B + 30));
            };
            boton.MouseLeave += (s, e) => boton.BackColor = color;
        }

        private void EstilizarCheckBoxes()
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    checkBox.ForeColor = Color.FromArgb(200, 200, 200);
                    checkBox.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                }
            }
        }

        private void AplicarEfectosBotones()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                if (control is Button btn)
                {
                    EstilizarBotonProducto(btn);
                }
            }
        }

        private void EstilizarBotonProducto(Button boton)
        {
            // Colores base
            Color colorBase = Color.FromArgb(60, 65, 75);
            Color colorHover = Color.FromArgb(80, 85, 95);
            Color colorPress = Color.FromArgb(40, 45, 55);

            // Configuración básica
            boton.BackColor = colorBase;
            boton.ForeColor = Color.White;
            boton.FlatStyle = FlatStyle.Flat;
            boton.FlatAppearance.BorderSize = 1;
            boton.FlatAppearance.BorderColor = Color.FromArgb(100, 100, 110);
            boton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            boton.Cursor = Cursors.Hand;
            boton.TextAlign = ContentAlignment.BottomCenter;
            boton.ImageAlign = ContentAlignment.TopCenter;

            // Efectos de interacción
            boton.MouseEnter += (s, e) => {
                boton.BackColor = colorHover;
                boton.FlatAppearance.BorderColor = Color.FromArgb(150, 150, 160);
            };

            boton.MouseLeave += (s, e) => {
                boton.BackColor = colorBase;
                boton.FlatAppearance.BorderColor = Color.FromArgb(100, 100, 110);
            };

            boton.MouseDown += (s, e) => boton.BackColor = colorPress;
            boton.MouseUp += (s, e) => boton.BackColor = colorHover;
        }

        private void EstilizarLabels()
        {
            // Colores por fila para mejor organización visual
            Color[] coloresPorFila = {
                Color.FromArgb(255, 193, 7),   // Amarillo - Fila 1
                Color.FromArgb(156, 39, 176),  // Púrpura - Fila 2  
                Color.FromArgb(255, 87, 34),   // Naranja - Fila 3
                Color.FromArgb(96, 125, 139),  // Gris azul - Fila 4
                Color.FromArgb(139, 195, 74)   // Verde claro - Fila 5
            };

            // Aplicar colores a labels por fila
            Label[] labelsFilas = { 
                label1, label2, label3,        // Fila 1
                label4, label5, label6,        // Fila 2
                label7, label8, label9,        // Fila 3
                label10, label11, label12,     // Fila 4
                label13, label14, label15      // Fila 5
            };

            for (int i = 0; i < labelsFilas.Length; i++)
            {
                int fila = i / 3;
                Label label = labelsFilas[i];
                
                label.BackColor = coloresPorFila[fila];
                label.ForeColor = Color.White;
                label.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
                label.TextAlign = ContentAlignment.MiddleCenter;
                
                // Agregar iconos según el tipo de producto
                string textoOriginal = label.Text;
                label.Text = textoOriginal;
            }
        }

        private void ConfigurarLabelsConStock()
        {
            // Array de labels y códigos correspondientes
            var labelsYCodigos = new (Label label, string codigo)[]
            {
                (label1, "A1"), (label2, "A2"), (label3, "A3"),
                (label4, "B1"), (label5, "B2"), (label6, "B3"),
                (label7, "C1"), (label8, "C2"), (label9, "C3"),
                (label10, "D1"), (label11, "D2"), (label12, "D3"),
                (label13, "E1"), (label14, "E2"), (label15, "E3")
            };

            foreach (var (label, codigo) in labelsYCodigos)
            {
                int stock = Operaciones.ObtenerStock(codigo);
                int precio = Operaciones.ObtenerPrecio(codigo);
                
                if (stock > 0)
                {
                    // Mostrar producto con stock disponible
                    label.Text = $"{codigo} ¢{precio}";
                    label.Visible = true;
                    
                    // También mostrar el botón correspondiente
                    OcultarMostrarBotonProducto(codigo, true);
                }
                else
                {
                    // Ocultar producto sin stock
                    label.Text = "AGOTADO";
                    //label.Visible = false;
                    
                    // También ocultar el botón correspondiente
                    OcultarMostrarBotonProducto(codigo, false);
                }
            }
        }

        private void OcultarMostrarBotonProducto(string codigo, bool mostrar)
        {
            // Mapear códigos a botones
            var codigosABotones = new Dictionary<string, Button>
            {
                {"A1", bproducto1}, {"A2", bproducto2}, {"A3", bproducto3},
                {"B1", bproducto4}, {"B2", bproducto5}, {"B3", bproducto6},
                {"C1", bproducto7}, {"C2", bproducto8}, {"C3", bproducto9},
                {"D1", bproducto10}, {"D2", bproducto11}, {"D3", bproducto12},
                {"E1", bproducto13}, {"E2", bproducto14}, {"E3", bproducto15}
            };

            if (codigosABotones.ContainsKey(codigo))
            {
                Button boton = codigosABotones[codigo];
                boton.Visible = mostrar;
                boton.Enabled = mostrar;
                

            }
        }

        // Método auxiliar para cargar y redimensionar imágenes
        private void LoadProductImage(string imagePath, Button button)
        {
            try
            {
                if (System.IO.File.Exists(imagePath))
                {
                    Image originalImage = Image.FromFile(imagePath);
                    Image resizedImage = new Bitmap(originalImage, new Size(120, 80));
                    button.Image = resizedImage;
                    button.ImageAlign = ContentAlignment.TopCenter;
                    originalImage.Dispose();
                }
                else
                {
                    // Si no hay imagen, usar un placeholder colorido
                    button.Image = CrearImagenPlaceholder(120, 80);
                }
            }
            catch
            {
                button.Image = CrearImagenPlaceholder(120, 80);
            }
        }

        private Image CrearImagenPlaceholder(int width, int height)
        {
            Bitmap placeholder = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(placeholder))
            {
                // Fondo degradado
                using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                    new Rectangle(0, 0, width, height),
                    Color.FromArgb(100, 120, 140),
                    Color.FromArgb(60, 80, 100),
                    45f))
                {
                    g.FillRectangle(brush, 0, 0, width, height);
                }

                // Texto placeholder
                using (var font = new Font("Segoe UI", 10, FontStyle.Bold))
                using (var textBrush = new SolidBrush(Color.White))
                {
                    string text = "🏪";
                    var size = g.MeasureString(text, font);
                    var x = (width - size.Width) / 2;
                    var y = (height - size.Height) / 2;
                    g.DrawString(text, font, textBrush, x, y);
                }
            }
            return placeholder;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // todas las imágenes de productos con redimensionado
            LoadProductImage(@"Imagenes\01.png", bproducto1);
            LoadProductImage(@"Imagenes\02.png", bproducto2);
            LoadProductImage(@"Imagenes\03.png", bproducto3);
            LoadProductImage(@"Imagenes\04.jpg", bproducto4);
            LoadProductImage(@"Imagenes\05.jpg", bproducto5);
            LoadProductImage(@"Imagenes\06.png", bproducto6);
            LoadProductImage(@"Imagenes\07.jpg", bproducto7);
            LoadProductImage(@"Imagenes\08.jpg", bproducto8);
            LoadProductImage(@"Imagenes\09.png", bproducto9);
            LoadProductImage(@"Imagenes\10.png", bproducto10);
            LoadProductImage(@"Imagenes\11.png", bproducto11);
            LoadProductImage(@"Imagenes\12.png", bproducto12);
            LoadProductImage(@"Imagenes\13.jpg", bproducto13);
            LoadProductImage(@"Imagenes\14.jpg", bproducto14);
            LoadProductImage(@"Imagenes\15.jpg", bproducto15);

            LResultado.Text = "🔹 Seleccione su producto favorito";

            // Configurar labels dinámicamente basado en stock
            ConfigurarLabelsConStock();

            // Aplicar estilos después de configurar el texto
            EstilizarLabels();
        }

        // Event Handlers
        private void button1_Click(object sender, EventArgs e)
        {
            // Feedback visual
            LResultado.ForeColor = Color.FromArgb(255, 193, 7); // Amarillo procesando
            LResultado.Text = "⏳ Procesando compra...";
            
            // Simular procesamiento
            System.Threading.Timer timer = null;
            timer = new System.Threading.Timer((obj) =>
            {
                this.Invoke(new Action(() =>
                {
                    string resultado = Operaciones.ComprarProduto(Tcodigo.Text, tmonto.Text);
                    
                    if (resultado.Contains("insuficiente") || resultado.Contains("No hay"))
                    {
                        LResultado.ForeColor = Color.FromArgb(244, 67, 54); // Rojo error
                        LResultado.Text = "❌ " + resultado;
                    }
                    else
                    {
                        LResultado.ForeColor = Color.FromArgb(76, 175, 80); // Verde éxito
                        LResultado.Text = "✅ " + resultado;
                        
                        // Actualizar la visualización después de la compra
                        ConfigurarLabelsConStock();
                    }
                    
                    timer?.Dispose();
                }));
            }, null, 1000, System.Threading.Timeout.Infinite);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Operaciones.Reporte(), "📊 Reporte de Inventario", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Tcodigo_TextChanged(object sender, EventArgs e)
        {
            // Validación en tiempo real
            string codigo = Tcodigo.Text.ToUpper();
            if (Operaciones.ProductoExiste(codigo))
            {
                float precio = Operaciones.ObtenerPrecio(codigo);
                string nombre = Operaciones.ProductoNombre(codigo);
                int stock = Operaciones.ObtenerStock(codigo);

                LResultado.ForeColor = Color.FromArgb(33, 150, 243); // Azul info
                LResultado.Text = $"💡 Producto {nombre}";
                LResultado.Text += $"\n Precio: ¢{precio}";
                LResultado.Text += $"\n Stock: {stock}";
              
            }
            else if (!string.IsNullOrEmpty(codigo))
            {
                LResultado.ForeColor = Color.FromArgb(255, 152, 0); // Naranja advertencia
                LResultado.Text = "⚠️ Código no válido";
            }
        }

        private void ingresarProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Adminitracion admin = new Adminitracion();
            
            // Suscribirse al evento ProductoAgregado para actualizar Form1 cuando se agregue un producto
            admin.ProductoAgregado += (s, args) => {
                ActualizarInventario();
            };
            
            admin.ShowDialog();
        }

        // Event handler para el menuStrip
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            // Este método maneja los clicks en el menu strip
        }

        // Event handlers existentes (vacíos pero necesarios para el designer)
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void bproducto1_Click(object sender, EventArgs e) { }
        private void button5_Click(object sender, EventArgs e) { }
        private void bproducto2_Click(object sender, EventArgs e) { }
        private void toolStripMenuItem1_Click(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
        private void label19_Click(object sender, EventArgs e) { }
        private void LResultado_Click(object sender, EventArgs e) { }
        private void label17_Click(object sender, EventArgs e) { }
        private void label2_Click_1(object sender, EventArgs e) { }

        private void labelMonto_Click(object sender, EventArgs e)
        {

        }
    }
}
