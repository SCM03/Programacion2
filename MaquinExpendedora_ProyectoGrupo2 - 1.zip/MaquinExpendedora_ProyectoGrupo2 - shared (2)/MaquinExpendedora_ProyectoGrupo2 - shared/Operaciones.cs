﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MaquinExpendedora_Ejercicio
{
    internal class Operaciones
    {
        public static Queue<int>[,] cola = new Queue<int>[5, 3];

        // Diccionario para almacenar productos vendidos: código -> cantidad vendida
        public static Dictionary<string, int> productosVendidos = new Dictionary<string, int>();

        // Lista para almacenar los precios de productos vendidos
        public static List<int> ventasRealizadas = new List<int>();

        // Diccionario para mapear códigos de productos a índices de matriz
        public static Dictionary<string, (int fila, int columna)> productos = new Dictionary<string, (int fila, int columna)>()
        {
            {"A1", (0, 0)}, {"A2", (0, 1)}, {"A3", (0, 2)},
            {"B1", (1, 0)}, {"B2", (1, 1)}, {"B3", (1, 2)},
            {"C1", (2, 0)}, {"C2", (2, 1)}, {"C3", (2, 2)},
            {"D1", (3, 0)}, {"D2", (3, 1)}, {"D3", (3, 2)},
            {"E1", (4, 0)}, {"E2", (4, 1)}, {"E3", (4, 2)}
        };

        // Diccionario para los precios de productos
        public static Dictionary<string, int> precios = new Dictionary<string, int>()
        {
            {"A1", 300}, {"A2", 400}, {"A3", 200},
            {"B1", 300}, {"B2", 400}, {"B3", 400},
            {"C1", 800}, {"C2", 600}, {"C3", 300},
            {"D1", 300}, {"D2", 300}, {"D3", 300},
            {"E1", 600}, {"E2", 600}, {"E3", 400}
        };

        public static Dictionary<string, String> dNombres = new Dictionary<string, String>()
        {
            {"A1", "Papitas     "}, {"A2", "Yogurt      "}, {"A3", "3-D Queso   "},
            {"B1", "Fresco leche"}, {"B2", "Agua        "}, {"B3", "Coca Cola   "},
            {"C1", "Mr. Beast   "}, {"C2", "Té Frío     "}, {"C3", "Bolita Queso"},
            {"D1", "Gost        "}, {"D2", "Pizzarolas  "}, {"D3", "Quesitos    "},
            {"E1", "Pringles    "}, {"E2", "Café Olé    "}, {"E3", "Rompope     "}
        };


        public static Dictionary<string, int> Precios { get => precios; set => precios = value; }
        public static Dictionary<string, string> DNombres { get => dNombres; set => dNombres = value; }


        public Operaciones()
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    cola[i, j] = new Queue<int>();
                }
            }
        }

        // Método simplificado usando el diccionario
        public static string buscarProducto(string codigo)
        {
            codigo = codigo.ToUpper();
            
            if (productos.ContainsKey(codigo))
            {
                var (fila, columna) = productos[codigo];
                cola[fila, columna].Enqueue(1);                
                String nombreProducto = dNombres[codigo];
                return $"Producto {nombreProducto}: {cola[fila, columna].Count()}";
            }

            return "Producto no encontrado";
        }

        // Método simplificado para comprar productos
        public static string ComprarProduto(string codigo, string precio)
        {
            codigo = codigo.ToUpper();

            if (!productos.ContainsKey(codigo))
            {
                return "Producto no encontrado";
            }

            var (fila, columna) = productos[codigo];
            int precioProducto = Precios[codigo];


            if (cola[fila, columna].Count <= 0)
            {
                return "No hay Producto";
            }

            if (!int.TryParse(precio, out int pago))
            {
                return "Monto inválido";
            }

            if (pago % 100 != 0)
            {
                return "Monto inválido";
            }

            if (pago < precioProducto)
            {
                return "Dinero insuficiente";
            }

            int vuelto = pago - precioProducto;
            cola[fila, columna].Dequeue();
            String nombreProducto = dNombres[codigo];

            // Registrar la venta en la lista
            RegistrarVenta(codigo);

            return $"Producto: {nombreProducto} " + $"\nDisponibles:{cola[fila, columna].Count()}" + $" \nVuelto: ¢{vuelto}";
        }

        // Nuevo método: Obtener precio de un producto
        public static int ObtenerPrecio(string codigo)
        {
            codigo = codigo.ToUpper();
            return Precios.ContainsKey(codigo) ? Precios[codigo] : 0;
        }

        // Nuevo método: Verificar si un producto existe
        public static bool ProductoExiste(string codigo)
        {
            return productos.ContainsKey(codigo.ToUpper());
        }


        public static string ProductoNombre(string codigo)
        {
            codigo = codigo.ToUpper();
            return DNombres.ContainsKey(codigo) ? DNombres[codigo] : "Producto no encontrado";
        }


        // Nuevo método: Obtener stock de un producto
        public static int ObtenerStock(string codigo)
        {
            codigo = codigo.ToUpper();
            if (productos.ContainsKey(codigo))
            {
                var (fila, columna) = productos[codigo];


                return cola[fila, columna].Count();
            }
            return 0;
        }

        // Método mejorado para reporte
        public static string Reporte()
        {
            string mensaje = "=== REPORTE DE INVENTARIO ===\n\n";

            foreach (var producto in productos)
            {
                string codigo = producto.Key;
                var (fila, columna) = producto.Value;
                int stock = cola[fila, columna].Count();
                var precio = Precios[codigo];
                string nombreProducto = dNombres[codigo];
                mensaje += $"{nombreProducto}: Stock = {stock}, Precio = ¢{precio}\n";
            }
            return mensaje;
        }
        public static string Cierre()
        {
            string mensaje = "=== CIERRE DE CAJA ===\n\n";

            // Calcular totales de ventas
            int totalVentas = 0;
            int cantidadProductosVendidos = 0;

            foreach (var venta in productosVendidos)
            {
                int cantidad = venta.Value;
                int precio = ObtenerPrecio(venta.Key);
                cantidadProductosVendidos += cantidad;
                totalVentas += (cantidad * precio);
            }

            mensaje += $"📊 RESUMEN DE VENTAS:\n";
            mensaje += $"• Cantidad de productos vendidos: {cantidadProductosVendidos}\n";
            mensaje += $"• Total recaudado: ¢{totalVentas}\n\n";

            // Mostrar detalle de ventas si hay
            if (productosVendidos.Count > 0)
            {
                mensaje += "💰 DETALLE DE VENTAS:\n";
                mensaje += TotalVendidos().Replace("=== TOTAL VENDIDOS ===\n\n", "");
                mensaje += "\n";
            }

            mensaje += "📦 INVENTARIO ACTUAL:\n";
            foreach (var producto in productos)
            {
                string codigo = producto.Key;
                var (fila, columna) = producto.Value;
                int stock = cola[fila, columna].Count();
                var precio = Precios[codigo];
                string nombreProducto = dNombres[codigo];
                mensaje += $"{nombreProducto}: Stock={stock}, Precio=¢{precio}\n";
            }
            return mensaje;
        }

        public static string TotalVendidos()
        {
            string mensaje = "=== TOTAL VENDIDOS ===\n\n";
            
            if (productosVendidos.Count == 0)
            {
                mensaje += "No se han realizado ventas aún.\n";
                return mensaje;
            }

            // Encabezados de la tabla
            mensaje += "Producto              Cantidad    Precio Unit.   Total\n";
            mensaje += "---------------------------------------------------\n";

            int totalGeneral = 0;

            foreach (var venta in productosVendidos)
            {
                string codigo = venta.Key;
                int cantidad = venta.Value;
                int precioUnitario = ObtenerPrecio(codigo);
                int totalProducto = cantidad * precioUnitario;
                string nombreProducto = ProductoNombre(codigo).Trim();

                // Formatear la línea con espacios para alineación
                mensaje += $"{nombreProducto,-20} {cantidad,8} {precioUnitario,12:C0} {totalProducto,8:C0}\n";
                
                totalGeneral += totalProducto;
            }

            mensaje += "---------------------------------------------------\n";
            mensaje += $"{"TOTAL GENERAL:",-20} {"",8} {"",12} {totalGeneral,8:C0}\n";

            return mensaje;
        }

        // método: Registrar venta
        public static void RegistrarVenta(string codigo)
        {
            codigo = codigo.ToUpper();
            if (ProductoExiste(codigo))
            {
                if (productosVendidos.ContainsKey(codigo))
                {
                    productosVendidos[codigo]++;
                }
                else
                {
                    productosVendidos[codigo] = 1;
                }
            }
        }

        public static void LlenarInicial() {

            // Llena cada producto con 5 unidades iniciales
            foreach (var producto in productos)
            {
                string codigo = producto.Key;
                var (fila, columna) = producto.Value;
                
                // Limpia la cola primero 
                cola[fila, columna].Clear();
                
                // Agregar 5 unidades de cada producto
                for (int k = 0; k < 5; k++)
                {
                    cola[fila, columna].Enqueue(1);
                }
            }
        }
    }
}

